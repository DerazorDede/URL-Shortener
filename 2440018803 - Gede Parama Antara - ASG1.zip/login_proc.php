<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "asg";

$connect = new mysqli($servername, $username, $password, $dbname);
if ($connect->connect_error) {
    die("Connection failed: " . $connect->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $connect->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);

    $stmt->execute();

    $stmt->bind_result($user_id, $db_username, $db_password);

    $stmt->fetch();

    $stmt->close();

    if (password_verify($password, $db_password)) {
        // Password is correct, set session variables and redirect to home page
        $_SESSION['user_id'] = $user_id;
        $_SESSION['username'] = $db_username;
        header("Location: index.php");
        exit;
    } else {
        // Password is incorrect, redirect back to login page with an error message
        header("Location: login.php?error=1");
        exit;
    }
}
$conn->close();
?>
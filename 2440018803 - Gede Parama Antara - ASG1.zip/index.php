<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "asg";

$connect = new mysqli($servername, $username, $password, $dbname);
if ($connect->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the list of URLs that the user has shortened right here
$user_id = $_SESSION['user_id'];
$sql = "SELECT long_url, short_url FROM urls WHERE user_id = $user_id";
$result = $connect->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    <h2>Your Shortened URL(s):</h2>
    <ul>
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<li><a href='" . $row['short_url'] . "'>" . $row['short_url'] . "</a> (Redirects to: " . $row['long_url'] . ")</li>";
            }
        } else{
            echo "<li>No shortened URLs yet.</li>";
        }
        ?>
    </ul>
    <form action="shorten_url.php" method="post">
        <label for="long_url">Long URL:</label>
        <input type="text" id="long_url" name="long_url" required><br>
        <label for="short_url">Short URL:</label>
        <input type="text" id="short_url" name="short_url"><br>
        <input type="submit" value="Shorten URL">
    </form>
    <a href="logout.php">Logout</a>
</body>
</html>
